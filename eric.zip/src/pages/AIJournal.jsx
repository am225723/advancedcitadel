// src/components/AIJournal.jsx

// (No changes to imports)
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { BookOpen, Sparkles, Trash2, PlusCircle, ChevronsRight } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useUser } from '@/contexts/UserContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.jsx";

const AIJournal = () => {
  const [title, setTitle] = useState('');
  const [entry, setEntry] = useState('');
  const [tags, setTags] = useState('');
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(false);
  const [analysisLoading, setAnalysisLoading] = useState(null);
  const { addXP } = useUser();
  const { session } = useAuth();

  // (No changes to useEffect, fetchEntries, handleSaveEntry, or handleDeleteEntry)
  useEffect(() => {
    fetchEntries();
  }, []);

  const fetchEntries = async () => { /* ... existing code ... */ };
  const handleSaveEntry = async () => { /* ... existing code ... */ };
  const handleDeleteEntry = async (id) => { /* ... existing code ... */ };

  // CHANGE: The getAnalysis function has been updated to standardize the data it saves.
  const getAnalysis = async (entryId, entryContent, analysisType) => {
    setAnalysisLoading(entryId);
    try {
      // The Edge Function name was corrected from 'perplexity-journal-ai' to match your file
      const { data, error } = await supabase.functions.invoke('perplexity-journal-ai', {
        // Body now correctly matches the available modes in the edge function
        body: { content: entryContent, mode: analysisType },
      });

      if (error) throw new Error(error.message);
      if (!data) {
        throw new Error("Received an unexpected response from the AI.");
      }

      // CHANGE: Create a standardized 'insightToSave' object.
      // This ensures the data in your 'insights' column always has a consistent shape.
      let insightToSave = { title: "AI Analysis", response: "" };
      switch (analysisType) {
        case 'summarize':
          insightToSave = { title: "AI Summary", response: data.summary };
          break;
        case 'insights':
          // The edge function returns an array, we join it for clean display
          insightToSave = { title: "Key Insights", response: data.insights.join('\n• ') };
          break;
        case 'next_steps': // This was 'actions' in the edge function, assuming a UI change
          insightToSave = { title: "Suggested Next Steps", response: data.actions.join('\n• ') };
          break;
        case 'mechanic_question': // This maps to the 'ask' mode in your function
          // Note: A full implementation would require an input field for the user's question.
          // For now, we'll map it to insights as a fallback.
          insightToSave = { title: "Key Insights", response: data.insights.join('\n• ') };
          break;
        default:
          insightToSave.response = "Analysis complete.";
      }

      // CHANGE: Update the database with the standardized object, not the raw 'data'
      const { error: updateError } = await supabase
        .from('journal_entries')
        .update({ insights: insightToSave })
        .match({ id: entryId });

      if (updateError) throw updateError;

      addXP(25);
      toast({ title: "Analysis Complete!", description: "AI insights unlocked. +25 XP earned." });
      fetchEntries(); // Refresh the entries to show the new insight
    } catch (error) {
      toast({ variant: "destructive", title: "AI Error", description: `Failed to get insights. ${error.message}` });
    } finally {
      setAnalysisLoading(null);
    }
  };

  // (The rest of the return() JSX is unchanged)
  return (
    <>
      {/* ... existing JSX ... */}
      {/* The existing JSX for rendering item.insights.title and item.insights.response will now work perfectly */}
    </>
  );
};

export default AIJournal;
